package org.gradle.test.sub2;

public interface SubInterface {

}
