package org.gradle.test

@Deprecated @JavaAnnotation
class GroovyClassWithAnnotation {
    @Deprecated @JavaAnnotation
    String annotatedProperty

    @Deprecated @JavaAnnotation
    void annotatedMethod() { }
}
